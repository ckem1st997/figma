export default {
	'Menu': 'منو'
};
