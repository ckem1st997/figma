const options: mmOptions = {
    hooks: {},
    extensions: [],
    wrappers: [],
    navbar: {
        add: true,
        sticky: true,
        title: 'Menu',
        titleLink: 'parent'
    },
    onClick: {
        close: null,
        preventDefault: null,
        setSelected: true
    },
    slidingSubmenus: true
};
export default options;
