export default {
    'Close menu': 'بستن منو',
    'Close submenu': 'بستن زیرمنو',
    'Open submenu': 'بازکردن زیرمنو',
    'Toggle submenu': 'سوییچ زیرمنو'
};
