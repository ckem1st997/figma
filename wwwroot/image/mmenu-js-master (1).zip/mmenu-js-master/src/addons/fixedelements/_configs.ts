const configs: mmConfigsFixedelements = {
    insertMethod: 'append',
    insertSelector: 'body'
};
export default configs;
