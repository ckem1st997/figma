export default {
    Search: 'جستجو',
    'No results found.': 'نتیجه‌ای یافت نشد.',
    cancel: 'انصراف'
};
